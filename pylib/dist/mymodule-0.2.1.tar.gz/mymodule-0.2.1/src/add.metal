/*
Derived sample notice: Copyright (c) 2020 Apple Inc.
The original sample license is preserved in ../licenses/Apple-sample-MIT.txt.
See ../THIRD_PARTY_NOTICES.md for sample sources and license notices.
SLAC modifications replace array addition with GPU priming, writing, and reads.
*/

#include <metal_stdlib>
#include <metal_atomic>
using namespace metal;

kernel void GPU_prime(device uint* inA,
                        device uint* inB,
                       device uint* result,
                       uint2 index [[thread_position_in_grid]])
{
    uint x=index.x;
    result[0]=inA[inB[x]];
    result[1]=inA[inB[x]+16];
}

kernel void GPU_write(device uint* inA,
                        device uint* inB,
                        device uint* result,
                       uint2 index [[thread_position_in_grid]])
{
    uint x=index.x;
    inA[inB[x]]=0;
}

kernel void read(device uint* inA,
                       device uint* result,
                       uint2 index [[thread_position_in_grid]])
{
    uint x=index.x;
    result[0]=inA[x*32];
}
