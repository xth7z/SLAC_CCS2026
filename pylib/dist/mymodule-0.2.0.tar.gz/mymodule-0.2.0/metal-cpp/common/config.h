/*
 * Copyright (c) 2022 CISPA.
 * Adapted from cispa/BranchDifferent; see ../../THIRD_PARTY_NOTICES.md.
 * Original MIT license: ../../licenses/CISPA-MIT.txt.
 * SLAC modifications adjust configuration, includes, and C++ integration.
 */

#ifndef CONFIG_H
#define CONFIG_H

/*
 * constants
 */

#define EVICTION 0
#define FLUSHING 1

#define COUNTER_THREAD 1


/*
 * generic configuration
 */
 
// higher value = more output
#define VERBOSITY 0

// use eviction
#define CACHE EVICTION

// use counter thread
#define TIMER COUNTER_THREAD

// page size
// 



/*
 * eviction configuration
 */
     
#if CACHE == EVICTION

    // Threshold for finding eviction sets (device-specific timing cycles).
    // If not defined, the eviction set algorithm will auto-calibrate.
    // Reference values: iPhone 7: 150, iPhone 8 Plus: 120, M1 Mac mini: 220
    // #define EVICTION_THRESHOLD 220

    // iPhone 7: 16
    // iPhone 8 Plus: 16
    // M1 Mac mini: 32
    // eviction set size
    #define EVICTION_SET_SIZE 16

    // size of memory to alloc
    #define EVICTION_MEMORY_SIZE 20 * 1024 * 1024

#endif /* EVICTION */


/*
 * benchmark configuration
 */
 
// how many data points to record
#define SAMPLES 1000000

// name of output file
#define OUTPUT "out.txt"

#endif /* CONFIG */
